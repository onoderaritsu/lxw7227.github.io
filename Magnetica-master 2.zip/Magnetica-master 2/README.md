# Magnetica

<p>Therese Henriksson
<br>
Yanchun Wu</p>

<hr>
<h3>Features (To be defined)</h3>
<p>Originally the plan was to create a form of educational word magnet game (puzzle together specific sentances). However, that will probably change now when we decided to work together.</p>

<h3>Checkpoint 1</h3>
<p>Words are neatly aligned at the top, and are draggable. Start up image is temporary.</p>

<p align="center">
  <img src="https://github.com/thereseh/Magnetica/blob/master/Images/ScreenShot_LaunchScreen.png" width="350"/>
  <img src="https://github.com/thereseh/Magnetica/blob/master/Images/ScreenShot_game.png" width="350"/>
</p>

<h3>Checkpoint 2</h3>
<p>We made some word banks, and there are multiple themes to choose from.</p>
<p align="center">
  <img src = "https://github.com/thereseh/Magnetica/blob/master/Images/34CC76CD09EC30B286E66A8A0D3BA89E.png">
  <img src = "https://github.com/thereseh/Magnetica/blob/master/Images/7E304902257707511C2D4F58F1F34C2B.png">
  <img src = "https://github.com/thereseh/Magnetica/blob/master/Images/9CEBAB3276766E5141D6AAE865246899.png">
</p>
